#!/bin/bash

mkimage -A arm -O linux -T kernel -C none -a 0x10000 -e 0x10000 -d FreeRTOS_ARM_Cortex-A9_QEMU.hex -n FreeRTOS FreeRTOS_Demo.uimg

