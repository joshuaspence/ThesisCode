#!/bin/bash

~/qemu-0.14.1/arm-softmmu/qemu-system-arm -M realview-pbx-a9 -nographic -kernel u-boot_bin_u-boot_realview.axf -net nic -net user,tftp=".",bootfile="FreeRTOS_Demo.uimg" -s -S
