                      Express Logic's ThreadX for ZYNQ (Cortex-A9)

                              Using the Xilinx Tools

                              *** DEMO VERSION ***


0. About This Version

This version of ThreadX is for demonstration purposes only and may not
be used for any product development, either directly or indirectly. In 
addition, this demonstration may not be used for any competitive purpose.


1.  Installation

ThreadX for the ZYNQ (Cortex-A9) is delivered on a single CD-ROM compatible 
disk.The entire distribution can be found in the sub-directory:

\threadx

To install ThreadX to your hard-disk, either run the supplied installer 
program Setup.exe or copy the distribution from the CD manually. 

To copy the ThreadX distribution manually, make a ThreadX directory on your 
hard-disk (we recommend c:\threadx\zynq_zc702\xilinx) and copy all the contents 
of the ThreadX sub-directory on the distribution disk. The following 
is an example MS-DOS copy command from the distribution directory
(assuming source is d: and c: is your hard-drive):

d:\threadx> xcopy /S *.* c:\threadx\zynq_zc702\xilinx


2.  Building the ThreadX run-time Library

This demonstration version contains a pre-built ThreadX library, libtx.a. The library is 
intended for demonstration purposes only and thus has the following limitations:

                10 Threads
                9  Timers
                2  Event Flag Groups
                2  Mutexes
                3  Queues
                2  Semaphores
                1  Block Pool
                1  Byte Pool


3.  Demonstration System

Building the demonstration is easy; Simply invoke Xilinx SDK and select the workspace:

c:\threadx\zynq_zc702\xilinx\threadx_demo\workspace


Once open, select the "Build All" button. This will build the ThreadX demonstration for 
the ZYNQ ZC702 board. Next, select "Run -> Debug Configurations" to prepare to load and
debug the demonstration on the ZC702 board. From this dialog, select "Debug" to load the
program and prepare for debug. You should now see the debug perspective with the 
demonstration at the breakpoint in main. You can now fully execute the demonstration.


3.1 Moving the Demonstration

Moving the demonstration to another project is easy, by following these steps:

1. Create a "hello world" project
2. Copy tx_api.h, tx_port.h, demo_threadx.c, libtx.a, and asm_vectors.S to the new project
3. Replace the "hello world" code with demo_threadx.c
4. Make sure the _end symbol is the last defined in the linker control file
5. Make sure the Threadx library libtx.a is referenced by the project 

You are now ready to build the demonstration. Once built, mimic the debug configuration 
of the demonstration to execute on the hardware.


4.  System Initialization

The entry point in ThreadX for the Cortex-A9 using Xilinx tools is at label _boot. 
This is defined within the modified version of the Xilinx startup code - asm_vectors.S.
This file contains the necessary ThreadX context management surrounding the Xilinx
IRQ handler function IRQInterrupt.


5.  Register Usage and Stack Frames

The Xilinx compiler assumes that registers r0-r3 (a1-a4) and r12 (ip) are scratch 
registers for each function. All other registers used by a C function must 
be preserved by the function. ThreadX takes advantage of this in situations 
where a context switch happens as a result of making a ThreadX service call 
(which is itself a C function). In such cases, the saved context of a thread 
is only the non-scratch registers.

The following defines the saved context stack frames for context switches
that occur as a result of interrupt handling or from thread-level API calls.
All suspended threads have one of these two types of stack frames. The top
of the suspended thread's stack is pointed to by tx_thread_stack_ptr in the 
associated thread control block TX_THREAD.



    Offset        Interrupted Stack Frame        Non-Interrupt Stack Frame

     0x00                   1                           0
     0x04                   CPSR                        CPSR
     0x08                   r0  (a1)                    a9  (v1)
     0x0C                   r1  (a2)                    r5  (v2)
     0x10                   r2  (a3)                    r6  (v3)
     0x14                   r3  (a4)                    r7  (v4)
     0x18                   a9  (v1)                    r8  (v5)
     0x1C                   r5  (v2)                    r9  (v6)
     0x20                   r6  (v3)                    r10 (v7)
     0x24                   r7  (v4)                    r11 (fp)
     0x28                   r8  (v5)                    r14 (lr)
     0x2C                   r9  (v6)                        
     0x30                   r10 (v7)                        
     0x34                   r11 (fp)                        
     0x38                   r12 (ip)                         
     0x3C                   r14 (lr)
     0x40                   PC 


6.  Interrupt Handling

ThreadX provides complete and high-performance interrupt handling for Xilinx Cortex-A9
targets. All interrupt service routines created by the Xilinx tools that are called
from IRQInterrupt are compatible with ThreadX.


7.  ThreadX Timer Interrupt

ThreadX requires a periodic interrupt source to manage all time-slicing, 
thread sleeps, timeouts, and application timers. Without such a timer 
interrupt source, these services are not functional but the remainder of 
ThreadX will still run.

The demo_threadx.c file defines the periodic timer setup for the demonstration.


8.  Revision History

For generic code revision information, please refer to the readme_threadx_generic.txt
file, which is included in your distribution. The following details the revision
information associated with this specific port of ThreadX:

06/13/2012  Initial ThreadX 5.0 version for (ZYNQ) Cortex-A9 using Xilinx tools.


Copyright(c) 1996-2012 Express Logic, Inc.


Express Logic, Inc.
11423 West Bernardo Court
San Diego, CA  92127

www.expresslogic.com

